from sklearn.base import BaseEstimator
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
import numpy as np
import pandas as pd
import optuna
from typing import Callable

from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier

class ModelBlender(BaseEstimator):
    def __init__(self, models, coefficients):
        self.models = models
        self.coefficients = coefficients

    def predict(self, X):

        weighted_predictions = np.zeros_like(self.models[0].predict_proba(X), dtype=np.float64)
        
        for model, coeff in zip(self.models, self.coefficients):
            model_predictions = model.predict_proba(X).astype(np.float64)
            weighted_predictions += coeff * model_predictions

        return (weighted_predictions[:, 1] >= 0.5)

def tune_and_blend_models(
    data: pd.DataFrame, 
    target_column: str, 
    metric: Callable,
    test_size: float = 0.2, 
    random_state: int = 42, 
    n_trials: int = 5
) -> ModelBlender:
    """
    Тюнинг моделей с помощью Optuna и их блендинг.

    :param data: DataFrame с данными.
    :param target_column: Название целевой колонки.
    :param test_size: Доля тестовой выборки.
    :param random_state: Начальное значение для генератора случайных чисел.
    :param n_trials: Количество итераций для Optuna.
    :return: Обученный объект ModelBlender.
    """
    # Разделение данных
    X = data.drop(columns=[target_column])
    y = data[target_column]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    
    # Инициализация моделей
    models = {
        "CatBoost": CatBoostClassifier(verbose=0, random_state=random_state),
        "LightGBM": LGBMClassifier(random_state=random_state),
        "XGBoost": XGBClassifier(random_state=random_state)
    }
    
    # Тюнинг моделей с помощью Optuna
    def tune_model(model_name: str, model):
        def objective(trial):
            if model_name == "CatBoost":
                model = CatBoostClassifier(
                    depth=trial.suggest_int("depth", 4, 10),
                    learning_rate= trial.suggest_float("learning_rate", 1e-3, 1e-1),
                    iterations = trial.suggest_int("iterations", 100, 500)
                )
            
            elif model_name == "LightGBM":
                model = LGBMClassifier(
                    num_leaves=trial.suggest_int("num_leaves", 20, 100),
                    learning_rate= trial.suggest_float("learning_rate", 1e-3, 1e-1),
                    n_estimators= trial.suggest_int("n_estimators", 100, 500)
                )
            
            elif model_name == "XGBoost":
                model = XGBClassifier(
                    max_depth= trial.suggest_int("max_depth", 4, 10),
                    learning_rate= trial.suggest_float("learning_rate", 1e-3, 1e-1),
                    n_estimators= trial.suggest_int("n_estimators", 100, 500)
                )
            
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            score = metric(y_test, y_pred)
            return score
        
        study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=random_state))
        study.optimize(lambda trial: objective(trial), n_trials=n_trials)
        
        print(f"Лучшие параметры для {model_name}: {study.best_params}")
        model.set_params(**study.best_params)
        model.fit(X_train, y_train)
        return model

    # блендинг
    def blend_models(models):
        def objective(trial):

            coefficients = [
                trial.suggest_float(f'coeff_{i}', 0, 1) for i in range(len(models))
            ]
            

            total_coeff = sum(coefficients)
            if total_coeff > 1:
                coefficients = [coeff / total_coeff for coeff in coefficients]
            

            combined_model = ModelBlender(models, coefficients)
            

            y_pred = combined_model.predict(X_test)
            

            score = metric(y_test, y_pred)
            
            return score
        
        study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=random_state))
    
        study.optimize(lambda trial: objective(trial), n_trials=n_trials)
        
        best_coefficients = [study.best_params[f'coeff_{i}'] for i in range(len(models))]

        total_coeff = sum(best_coefficients)
        if total_coeff > 1:
            best_coefficients = [coeff / total_coeff for coeff in best_coefficients]

        combination = ModelBlender(models, best_coefficients)

        return combination

    tuned_models = {}
    for name, model in models.items():
        tuned_models[name] = tune_model(name, model)

    blender = blend_models(models=list(tuned_models.values()))

    y_pred = blender.predict(X_test)
    test_metric = metric(y_test, y_pred)
    print(f"Значение метрики у блендинга на тестовой выборке: {test_metric}")
    
    return blender


"""
from sklearn.metrics import f1_score as metric_func

if __name__ == "__main__":
    # Примерные данные
    data = pd.DataFrame({
        "feature1": [1, 2, 3, 4, 5],
        "feature2": [10, 20, 30, 40, 50],
        "feature3": [5, 4, 3, 2, 1],
        "target": [0, 1, 0, 1, 0]
    })
    
    # Тюнинг моделей и их блендинг
    blender = tune_and_blend_models(data, target_column="target", metric=f1_score)
"""